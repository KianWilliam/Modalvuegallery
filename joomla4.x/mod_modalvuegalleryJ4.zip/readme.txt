ModalVueGallery version 1.0.0  is a free software which is developed by
KWProductions Co., it is written clearly, too clear 
to add any comments excepting those needed for GPL,
Just create the folder you input its name in the module background via media(In the images folder)
The license is GNU/GPLv3
It is written for joomla 3.x,fill all formfields in 
module to make it work, you may download the module at:
https://extensions.kwproductions121.ir/mymodules/modalvuegallery-download.html
In case of any problem contact me at:
webarchitect@kwproductions121.ir
long live science.
